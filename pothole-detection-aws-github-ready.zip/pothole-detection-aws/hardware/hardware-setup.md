# Hardware Setup

Add final wiring and assembly instructions here.
