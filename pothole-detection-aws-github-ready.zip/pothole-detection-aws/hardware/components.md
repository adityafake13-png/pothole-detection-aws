# Hardware Components

Add the final verified component list here.
