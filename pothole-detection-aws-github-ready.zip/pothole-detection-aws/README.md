# 🚧 AI-Based Pothole Detection and Road Monitoring System

An academic prototype for automated pothole detection and road-condition monitoring using Raspberry Pi, sensors, AWS cloud services, and a web dashboard.

## Project Overview

The system is designed to:
- Detect potholes using sensors
- Measure pothole dimensions/depth
- Capture pothole images
- Record route/location information
- Send data to AWS
- Store images in Amazon S3
- Store structured data in Amazon DynamoDB
- Process calculations with AWS Lambda
- Display collected information through a web dashboard

## System Architecture

```text
Road / Track
     ↓
Sensors → Raspberry Pi → Camera / Location
     ↓
API Gateway
     ↓
AWS Lambda
   ↙     ↘
S3      DynamoDB
   \     /
    Web Dashboard
```

## AWS Services

| Service | Purpose |
|---|---|
| Amazon S3 | Pothole image storage |
| Amazon DynamoDB | Pothole data storage |
| AWS Lambda | Data processing and calculations |
| Amazon API Gateway | API communication |
| AWS IAM | Permissions |
| Amazon CloudWatch | Monitoring |

**AWS Region:** `ap-south-1` (Mumbai)

## DynamoDB

Current table:

`PotholeData`

Example record:

```json
{
  "pothole_id": "P003",
  "route_id": "Route-1",
  "length_cm": 12,
  "width_cm": 8,
  "depth_cm": 2,
  "latitude": 21.1458,
  "longitude": 79.0882,
  "image_key": "route-1/P003.jpg"
}
```

Basic volume calculation:

`Volume = Length × Width × Depth`

## S3 Structure

```text
route-1/
  P001.jpg
  P002.jpg
  P003.jpg

route-2/
  P001.jpg
  P002.jpg
```

## Route Workflow

```text
Start Survey
     ↓
Data Collection
     ↓
Potholes Detected
     ↓
Stop Survey
     ↓
Route 1 Completed
     ↓
Start Survey Again
     ↓
Route 2
```

## Hardware

Planned/used prototype components include:
- Raspberry Pi
- Distance/ultrasonic sensor
- Camera
- DC motors
- Motor driver
- Battery/power supply
- Vehicle chassis
- Prototype road track

## Technologies

**Hardware:** Raspberry Pi, sensors, camera, DC motors

**Programming:** Python, HTML, CSS, JavaScript

**Cloud:** AWS S3, DynamoDB, Lambda, API Gateway, IAM, CloudWatch

## Repository Structure

```text
hardware/        Hardware documentation and diagrams
raspberry-pi/    Raspberry Pi programs
aws/             AWS configuration/documentation
web-dashboard/   Dashboard source code
docs/            Diagrams, report and presentation
sample-data/     Sample pothole data
```

## Security

Never upload:
- AWS access keys
- AWS secret keys
- Passwords
- `.env` files
- Private credentials

This repository is for an academic prototype. Measurements and repair estimates may differ from real-world engineering surveys.

## Project Team

B.Tech Final Year Project  
Priyadarshini College of Engineering, Nagpur  
Domain: IoT | AWS | Cloud Computing | Web Development | Road Monitoring
