# DynamoDB Table Structure

Table: `PotholeData`

Document the final keys and attributes here.
