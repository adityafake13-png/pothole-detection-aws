# S3 Bucket Structure

Document the folder/key structure here. Do not publish credentials.
